'use strict';

module.exports = {
  categories: '*',
  numberOfQuestions: 3
};