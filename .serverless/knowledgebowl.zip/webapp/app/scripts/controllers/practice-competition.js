'use strict';

angular.module('knowledgebowl').controller('PracticeCompetitionCtrl', function () {
  var ctrl = this;
});
